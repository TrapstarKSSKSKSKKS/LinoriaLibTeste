# LinoriaLib
A Roblox UI library inspired by Splix, BBot and many others. Developed by Inori. Maintained by Wally.
Used in the Linoria script hub: https://lindseyhost.com

![UI](https://i.imgur.com/qs0Hqc6.png)
